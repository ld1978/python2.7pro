#!/usr/bin/env python
# -*-coding:utf-8-*-
# __author__="Liudong"
import json

'''
product_list = {
    '家电类': [('乐视电视', 7000), ('海尔冰箱', 5000), ('小天鹅洗衣机', 2000)],
    '衣服类': [('西装', 8000), ('休闲夹克', 2000), ('运动服', 800)],
    '手机类': [('Iphone7', 7000), ('小米Note', 2000), ('华为', 1000)],
    '车类': [('奔驰ML', 800000), ('特斯拉', 700000), ('奥迪Q7', 750000)]
}
'''


def purchase_pro():  # 购物过程
    product_list = {
        '家电类': [('乐视电视', 7000), ('海尔冰箱', 5000), ('小天鹅洗衣机', 2000)],
        '衣服类': [('西装', 8000), ('休闲夹克', 2000), ('运动服', 800)],
        '手机类': [('Iphone7', 7000), ('小米Note', 2000), ('华为', 1000)],
        '车类': [('奔驰ML', 800000), ('特斯拉', 700000), ('奥迪Q7', 750000)]}
    while True:
        print("Products list".center(50, '-'))
        for index, item in product_list.keys:
            print(index, item)
        class1_choice = input('choose 1st class:1-4 (q:quit)')
        if class1_choice == 'q': break
        if class1_choice == '1':
            pass


def display_shop_car():
    pass


if __name__ == '__main__':
    # user_info={'root':[123,5000],'sys':[123,10000],'admin':[123,200000]}
    # json.dump(user_info, open('user_info.txt','w'))#把用户信息以user:pass:amount的格式写入文本文件
    # purchase_log={'root':[['iphone7' ,2 ,'2016-6-10'],['西装',1 ,'2015-5-2']],
    #             'sys':[['乐视电视',1,'2016-9-20'] ,['华为',5,'2016-7-15']],
    #             'admin':[['乐视电视',1,'2016-8-10'] ,['运动服',3,'2016-10-10']]
    #              }
    # json.dump(purchase_log,open('purchase_log.txt','w',encoding='utf-8'))

    shop_car = []
    welcom_msg = 'Welcome to Shopping Home'.center(50, '-')
    print(welcom_msg)
    for i in range(3):
        username = input('Please input your username:[q=quit]')
        if username == 'q':
            exit()
        with open('user_info.txt', 'r', encoding='utf-8') as user_account:  # 读取用户信息
            user_info = json.load(user_account)  # 用json读取文件，字典格式
        for user_name in user_info.keys():  # 判断用户名是否存在
            # print(user_info[user_name][0])
            # print(user_name)
            # print(username)
            j = 0
            while j < 3:  # 给3次输入密码机会
                password = input('Please input your password:')
                if password == str(user_info[user_name][0]):
                    print('login successed! Have a happy shopping Time!')
                    while True:
                        print('#' * 50)
                        print('1.查看购买记录\n2.充值\n3.查询余额\n4.购物\n5.查看购物车\n[q:quit]')
                        user_want = input('What do you do?')
                        if user_want == 'q':
                            exit()
                        if user_want == '1':
                            print('user %s purchase log list:'.center(50, '*') % user_name)
                            with open('purchase_log.txt', 'r', encoding='utf-8') as purchase_log:  # 读取购买记录文件
                                user_purchase_log = json.load(purchase_log)
                                print(user_purchase_log[username])
                        if user_want == '2':
                            print('*' * 50)
                            charge_amount = input('please input amount you want to charge:')
                            # user_info_amountw = json.load('user_info.txt', 'r')
                            user_info[username][1] += int(charge_amount)
                            # print(user_info)
                            json.dump(user_info, open('user_info.txt', 'w'))
                            print('charge successed!')
                        if user_want == '3':
                            print('*' * 50)
                            print('your account is ￥%s' % user_info[user_name][1])
                        if user_want == '4':
                            product_list = {
                                '家电类': [('乐视电视', 7000), ('海尔冰箱', 5000), ('小天鹅洗衣机', 2000)],
                                '衣服类': [('西装', 8000), ('休闲夹克', 2000), ('运动服', 800)],
                                '手机类': [('Iphone7', 7000), ('小米Note', 2000), ('华为', 1000)],
                                '车类': [('奔驰ML', 800000), ('特斯拉', 700000), ('奥迪Q7', 750000)]}
                            while True:
                                print("Products list".center(50, '-'))
                                for index, item in enumerate(product_list):
                                    print(index, item)
                                class1_choice = input('choose 1st class 0-3 to enter:(q:quit)')
                                if class1_choice == 'q': exit()
                                if class1_choice == '0':
                                    print('choose a product number to buy:')
                                    # print(product_list[0])
                                    for index,item in enumerate(product_list[class1_choice]):
                                        print(item)

                        if user_want == '5':
                            display_shop_car()
                else:
                    print('Invalid username or password...')
                    print('this is the %d time(s)' % (j + 1))
                    j += 1
            else:
                print('Forget password? Please send a mail to Administrator,bye')
                user_account.close()
                exit()
salary = input("Input your salary:")
if salary.isdigit():
    salary = int(salary)
else:
    exit("Invalid data type...")
